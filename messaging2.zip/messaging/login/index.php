<?php 
session_name("user");
session_start();
require("../api/connect.php");
$username = $_POST["username"];
$password = $_POST["password"];
if($username != null && $password != null){
    $sql = "SELECT * FROM users WHERE username = '".$username."' AND password = '".$password."';";
    $result = mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)){
        $_SESSION["username"] = $row["username"];
        $_SESSION["password"] = $row["password"];

    }
}
function checkSession(){
    if($_SESSION["username"] != null && $_SESSION["password"] != null){
        header("Location: ../users.php");
    }
}
checkSession();
?>
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
<style>
.login-form{
    width:100%;
    height: 100%;
    margin:auto;
}
.input{
    width:90%;
    margin: 5%;
    height:30px;
    color: black;
    font-weight:bold;
    font-size: 16px;
    border: 1px solid gray;
}
.submit{
    width:90%;
    margin: 5%;
    border: 2px solid gray;
    background-color: green;
    color: white;
    height:40px;
}
h2{
    width:90%;
    margin: 5%;
    text-align:center;
    color:black;
    background-color: white;
    font-family: 'Open Sans', sans-serif;

}
.hr{
    width:90%;
    margin: 5%;
    color: gray;
    height: 1px;
}
label{
    font-family: 'Open Sans', sans-serif;
    width:90%;
    margin: 5%;
    color: black;
    font-size: 15px;
    font-weight:bold;
}
</style>
</head>
<body>
<div class="login-form">
<h2>Mesaj Sistemine Giriş Yap</h2>
<hr class="hr" />
<form method="POST">
<label for="username">Kullanıcı Adı:</label>
<input class="input" id="username" type="text" name="username" value="" placeholder="Kullanıcı Adınızı Giriniz" />
<label for="password">Şifre:</label>
<input class="input" id="password" type="password" name="password" value="" placeholder="Şifreniz" />
<button class="submit" type="submit">Giriş Yap</button>
</form>
</div>
</body>
</html>