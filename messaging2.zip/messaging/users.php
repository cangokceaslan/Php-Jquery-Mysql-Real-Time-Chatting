<?php 
session_name("user");
session_start();
require("./api/connect.php");
if($_SESSION["username"]==null || $_SESSION["password"]==null){
    header("Location: ./login/");
    die();
}
$sql = "SELECT * FROM users WHERE username <> '".$_SESSION["username"]."';";
$result = mysqli_query($conn, $sql);
$arr = [];
while($row = mysqli_fetch_assoc($result)){
    array_push($arr,$row);
}
?>
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
ul{
    list-style:none;
    width: 100%;
    margin: 0px;
    padding: 0px;
}
.buttontype{
    height:40px;
    background-color: green;
    color: white;
    min-width: 90%;
    margin:5%;
    text-align: center;
}
.buttontype > a{
    color: white;
    font-size: 20px;
    height: 40px;
}
h2{
    width:100%;
    margin-bottom: 5%;
    text-align:center;
    color:black;
    background-color: gold;
    font-family: 'Open Sans', sans-serif;

}
</style>
</head>
<body>
<h2>Panel Sayfası</h2>
<?php
echo "<ul>";
for($i = 0; $i < count($arr); $i++){
    echo "<li class='buttontype'><a href='http://localhost/?sender=".$_SESSION["username"]."&receiver=".$arr[$i]["username"]."'>".$arr[$i]["name"]." (@".$arr[$i]["username"].")</a></li>";
}
echo "</ul>";

?>
</body>
</html>